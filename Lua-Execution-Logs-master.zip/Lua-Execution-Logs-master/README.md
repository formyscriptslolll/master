# hello it's simple execution logs for your lua script (there may be syntax errors etc) it's for educational purposes (fix errors and get it to work its not hard thank you)
